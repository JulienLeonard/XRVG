README.txt

Ruby/PureImage 0.1.2.

Resources:

index.html               Specification and reference manual.
build.xml                Ant build file for Java sources.
README.txt               This file.
LICENSE.txt              License file.
docs/api/                PureImage Java API reference manual
src/                     PureImage Java source.
samples/                 Sample source files.
fonts/                   Bitmap font files.
                         �݂������(Mikachan) font:
                           http://www001.upp.so-net.ne.jp/mikachan/
                         �����Ȃ�(Sazanami) font:
                           http://wiki.fdiary.net/font/?sazanami
images/                  Sample images.
lib/pureimage.rb         Ruby/PureImage library.
lib/pureimage.jar        PureImage Java library.
